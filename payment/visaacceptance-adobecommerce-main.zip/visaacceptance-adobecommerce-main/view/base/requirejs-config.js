var config = {
    config: {
        mixins: {
            'Magento_Ui/js/lib/validation/validator': {
                'CyberSource_Payment/js/lib/validation/rules-mixin': true
            }
        }
    }
}