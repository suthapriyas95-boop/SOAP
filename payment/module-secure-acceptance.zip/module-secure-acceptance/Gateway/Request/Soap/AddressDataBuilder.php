<?php

namespace CyberSource\SecureAcceptance\Gateway\Request\Soap;

/**
 * @depecated see parent class
 */
class AddressDataBuilder extends \CyberSource\Core\Gateway\Request\Soap\AddressDataBuilder
{
}
