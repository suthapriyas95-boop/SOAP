<?php

namespace CyberSource\SecureAcceptance\Gateway\Request\Soap;

/**
 *
 * @deprecated See parent
 */
class ItemsDataBuilder extends \CyberSource\Core\Gateway\Request\Soap\ItemsBuilder
{
}
