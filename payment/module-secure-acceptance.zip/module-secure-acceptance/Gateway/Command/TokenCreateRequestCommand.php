<?php
/**
 *
 */

namespace CyberSource\SecureAcceptance\Gateway\Command;

use CyberSource\Core\Gateway\Command\CreateRequestCommand;

class TokenCreateRequestCommand extends CreateRequestCommand
{

    const COMMAND_CODE = 'create_token';

}
