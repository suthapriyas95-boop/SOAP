<?php
/**
 *
 */

namespace CyberSource\SecureAcceptance\Gateway\Command;

use CyberSource\Core\Gateway\Command\HandleResponseCommand;

class TokenHandleResponseCommand extends HandleResponseCommand
{

    const COMMAND_NAME = 'process_token';

}
